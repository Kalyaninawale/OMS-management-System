import axios from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

const API = axios.create({
  baseURL: API_BASE_URL,
});

// Add Authorization header automatically if token exists
API.interceptors.request.use(config => {
  const token = localStorage.getItem('token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Optional: global error handling for 401 Unauthorized
API.interceptors.response.use(
  response => response,
  error => {
    if (error.response && error.response.status === 401) {
      console.log('Unauthorized! Redirect to login if needed.');
      // Example: window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

/* ================== PRODUCT APIs ================== */
export const getProducts = () => API.get('/products');
export const getProductById = (id) => API.get(`/products/${id}`);
export const createProduct = (product) => API.post('/products', product);
export const updateProduct = (id, product) => API.put(`/products/${id}`, product);
export const deleteProduct = (id) => API.delete(`/products/${id}`);

/* ================== CUSTOMER APIs ================== */
export const fetchCustomers = (page = 0, size = 10) =>
  API.get('/customers', { params: { page, size } });
export const getCustomerById = (id) => API.get(`/customers/${id}`);
export const createCustomer = (customerData) => API.post('/customers', customerData);
export const updateCustomer = (id, customerData) => API.put(`/customers/${id}`, customerData);
export const deleteCustomer = (id) => API.delete(`/customers/${id}`);

/* ================== SUPPLIER APIs ================== */
export const fetchSuppliers = (page = 0, size = 10) =>
  API.get('/suppliers', { params: { page, size } });
export const getSupplierById = (id) => API.get(`/suppliers/${id}`);
export const createSupplier = (supplierData) => API.post('/suppliers', supplierData);
export const updateSupplier = (id, supplierData) => API.put(`/suppliers/${id}`, supplierData);
export const deleteSupplier = (id) => API.delete(`/suppliers/${id}`);

/* ================== SALES ORDER APIs ================== */
export const fetchSalesOrders = (page = 0, size = 10) =>
  API.get('/sales-orders', { params: { page, size } });
export const getSalesOrderById = (id) => API.get(`/sales-orders/${id}`);
export const createSalesOrder = (orderData) => API.post('/sales-orders', orderData);
export const updateSalesOrder = (id, orderData) => API.put(`/sales-orders/${id}`, orderData);
export const deleteSalesOrder = (id) => API.delete(`/sales-orders/${id}`);

/* ================== SALES ORDER ITEM APIs ================== */
export const fetchSalesOrderItems = (orderId) =>
  API.get(`/sales-orders/${orderId}/items`);
export const addSalesOrderItem = (orderId, itemData) =>
  API.post(`/sales-orders/${orderId}/items`, itemData);
export const updateSalesOrderItem = (orderId, itemId, itemData) =>
  API.put(`/sales-orders/${orderId}/items/${itemId}`, itemData);
export const deleteSalesOrderItem = (orderId, itemId) =>
  API.delete(`/sales-orders/${orderId}/items/${itemId}`);

/* ================== PURCHASE ORDER APIs ================== */
export const fetchPurchaseOrders = (page = 0, size = 10) =>
  API.get('/purchase-orders', { params: { page, size } });
export const createPurchaseOrder = (orderData) =>
  API.post('/purchase-orders', orderData);
export const updatePurchaseOrderStatus = (id, status) =>
  API.put(`/purchase-orders/${id}/status?status=${status}`);

/* ================== GRN APIs ================== */
export const fetchGRNs = () => API.get('/grns');
export const getGRNById = (id) => API.get(`/grns/${id}`);
export const createGRN = (grnData) => API.post('/grns', grnData);


/* ================== DASHBOARD APIs ================== */

// GET sales summary
export const getSalesSummary = () => API.get('/dashboard/sales-summary');

// GET purchase summary
export const getPurchaseSummary = () => API.get('/dashboard/purchase-summary');

// GET low stock alerts
export const getStockAlerts = () => API.get('/dashboard/stock-alerts');

// GET pending invoices
export const getPendingInvoices = () => API.get('/dashboard/pending-invoices');

// Optional: fetch all dashboard data at once
export const getDashboardData = async () => {
  const [salesRes, purchaseRes, stockRes, pendingRes] = await Promise.all([
    getSalesSummary(),
    getPurchaseSummary(),
    getStockAlerts(),
    getPendingInvoices()
  ]);

  return {
    salesSummary: salesRes.data,
    purchaseSummary: purchaseRes.data,
    stockAlerts: stockRes.data.lowStockProducts || [],
    pendingInvoices: pendingRes.data.pendingInvoices || [],
  };
};




// ==================== Invoice APIs ====================

// GET all invoices
export const getAllInvoices = () => API.get("/invoices");

// GET invoice by ID
export const getInvoiceById = (id) => API.get(`/invoices/${id}`);

// POST generate invoice from sales order
export const generateInvoice = (salesOrderId) =>
  API.post(`/invoices/generate/${salesOrderId}`);

// POST create invoice manually (optional)
export const createInvoice = (invoiceData) => API.post("/invoices", invoiceData);


/* ================== AUTH APIs ================== */
export const login = (credentials) => API.post('/auth/login', credentials);
export const register = (userData) => API.post('/auth/register', userData);
export const logout = () => {
  localStorage.removeItem('token');
};

export default API;
