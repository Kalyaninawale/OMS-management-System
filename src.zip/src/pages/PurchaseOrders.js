import React, { useEffect, useState } from "react";
import { fetchPurchaseOrders, updatePurchaseOrderStatus } from "../api";

const PurchaseOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const response = await fetchPurchaseOrders();
      setOrders(response.data.content || response.data);
    } catch (error) {
      console.error("Error fetching purchase orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (id, newStatus) => {
    await updatePurchaseOrderStatus(id, newStatus);
    loadOrders();
  };

  if (loading) return <p>Loading purchase orders...</p>;

  return (
    <center>
    <div style={{ padding: "20px" }}>
      <h2 style={{ fontSize: "24px", fontWeight: "bold", marginBottom: "20px" }}>
        Purchase Orders
      </h2>
      {orders.length === 0 ? (
        <p>No purchase orders found.</p>
      ) : (
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            border: "1px solid black",
          }}
        >
          <thead style={{ backgroundColor: "#f2f2f2" }}>
            <tr>
              <th style={{ border: "1px solid black", padding: "8px" }}>
                Order ID
              </th>
              <th style={{ border: "1px solid black", padding: "8px" }}>
                Supplier
              </th>
              <th style={{ border: "1px solid black", padding: "8px" }}>
                Products
              </th>
              <th style={{ border: "1px solid black", padding: "8px" }}>
                Expected Delivery
              </th>
              <th style={{ border: "1px solid black", padding: "8px" }}>
                Status
              </th>
              <th style={{ border: "1px solid black", padding: "8px" }}>
                Actions
              </th>
            </tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id} style={{ textAlign: "center" }}>
                <td style={{ border: "1px solid black", padding: "8px" }}>
                  {order.id}
                </td>
                <td style={{ border: "1px solid black", padding: "8px" }}>
                  {order.supplier?.name}
                </td>
                <td
                  style={{
                    border: "1px solid black",
                    padding: "8px",
                    textAlign: "left",
                  }}
                >
                  <ul style={{ margin: 0, paddingLeft: "20px" }}>
                    {order.items?.map((item) => (
                      <li key={item.id}>
                        {item.product?.productName} × {item.quantity}
                      </li>
                    ))}
                  </ul>
                </td>
                <td style={{ border: "1px solid black", padding: "8px" }}>
                  {order.expectedDeliveryDate}
                </td>
                <td style={{ border: "1px solid black", padding: "8px" }}>
                  {order.status}
                </td>
                <td style={{ border: "1px solid black", padding: "8px" }}>
                  {order.status === "ORDERED" && (
                    <button
                      onClick={() => handleStatusChange(order.id, "RECEIVED")}
                      style={{
                        padding: "5px 10px",
                        backgroundColor: "green",
                        color: "white",
                        border: "none",
                        borderRadius: "5px",
                        cursor: "pointer",
                      }}
                    >
                      Mark Received
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div></center>
  );
};

export default PurchaseOrders;
