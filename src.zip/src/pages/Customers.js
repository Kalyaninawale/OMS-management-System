import React, { useEffect, useState } from "react";
import '../App.css';
import {
  fetchCustomers,
  createCustomer,
} from "../api";
import {
  TextField,
  Button,
  Box,
  Typography,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
} from "@mui/material";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

const schema = yup.object({
  name: yup.string().required("Name is required"),
  email: yup.string().email("Must be valid email").required("Email is required"),
  phone: yup.string(),
  address: yup.string(),
  gstin: yup.string().optional(),
});

export default function Customers() {
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(schema),
  });

  const loadCustomers = async () => {
    setLoading(true);
    try {
      const res = await fetchCustomers();
      setCustomers(res.data.content);
    } catch (error) {
      console.error("Failed to fetch customers", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const onSubmit = async (data) => {
    try {
      await createCustomer(data);
      reset();
      loadCustomers();
    } catch (error) {
      console.error("Failed to create customer", error);
      alert("Error creating customer");
    }
  };

  return (
    <center>
    <Box p={2}>
      <Typography variant="h5" mb={2}>Customers</Typography>

      <form onSubmit={handleSubmit(onSubmit)}>
        <Box display="flex" flexDirection="column" maxWidth={400} mb={3}>
          <TextField
            label="Name"
            {...register("name")}
            error={!!errors.name}
            helperText={errors.name?.message}
            margin="normal"
            fullWidth
          />
          <TextField
            label="Email"
            {...register("email")}
            error={!!errors.email}
            helperText={errors.email?.message}
            margin="normal"
            fullWidth
          />
          <TextField label="Phone" {...register("phone")} margin="normal" fullWidth />
          <TextField label="Address" {...register("address")} margin="normal" fullWidth />
          <TextField label="GSTIN" {...register("gstin")} margin="normal" fullWidth />

          <Button variant="contained" color="primary" type="submit" sx={{ mt: 2 }}>
            Add Customer
          </Button>
        </Box>
      </form>

      <Typography variant="h6" mb={1}>Customer List</Typography>

      {loading ? (
        <Typography>Loading...</Typography>
      ) : (
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Name</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Phone</TableCell>
              <TableCell>Address</TableCell>
              <TableCell>GSTIN</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {customers.map((c) => (
              <TableRow key={c.id}>
                <TableCell>{c.name}</TableCell>
                <TableCell>{c.email}</TableCell>
                <TableCell>{c.phone}</TableCell>
                <TableCell>{c.address}</TableCell>
                <TableCell>{c.gstin}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
    </Box></center>
  );
}
