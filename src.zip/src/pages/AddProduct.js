// src/pages/products/AddProduct.js
import React, { useState } from "react";
import { createProduct } from "../api";
import { useNavigate } from "react-router-dom";

export default function AddProduct() {
  const [product, setProduct] = useState({
    productName: "",
    sku: "",
    category: "",
    unitPrice: "",
    currentStock: "",
    reorderLevel: "",
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createProduct(product);
      navigate("/products");
    } catch (error) {
      console.error("Error creating product:", error);
    }
  };

  return (
   <center> <div>
      <h2>Add Product</h2>
      <form onSubmit={handleSubmit}>
        {Object.keys(product).map((key) => (
          <div key={key}>
            <label>{key}</label>
            <input
              type="text"
              name={key}
              value={product[key]}
              onChange={handleChange}
              required
            />
          </div>
        ))}
        <button type="submit">Save</button>
      </form>
    </div></center>
  );
}
