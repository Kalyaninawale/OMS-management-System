import React, { useState, useEffect } from "react";
import API from "../api";

const GrnForm = ({ onGrnCreated }) => {
  const [purchaseOrders, setPurchaseOrders] = useState([]);
  const [purchaseOrderId, setPurchaseOrderId] = useState("");
  const [receivedDate, setReceivedDate] = useState("");
  const [items, setItems] = useState([{ productId: "", quantityReceived: 0 }]);

  useEffect(() => {
    // Fetch purchase orders for dropdown
    API.get("/purchase-orders")
      .then((res) => setPurchaseOrders(res.data))
      .catch((err) => console.error(err));
  }, []);

  const handleItemChange = (index, field, value) => {
    const updated = [...items];
    updated[index][field] = value;
    setItems(updated);
  };

  const addItem = () => setItems([...items, { productId: "", quantityReceived: 0 }]);

  const removeItem = (index) => setItems(items.filter((_, i) => i !== index));

  const handleSubmit = (e) => {
    e.preventDefault();
    API.post("/grns", { purchaseOrderId, receivedDate, items })
      .then((res) => {
        alert("GRN created successfully!");
        onGrnCreated();
        setPurchaseOrderId("");
        setReceivedDate("");
        setItems([{ productId: "", quantityReceived: 0 }]);
      })
      .catch((err) => console.error(err));
  };

  return (
    <center>
    <form onSubmit={handleSubmit}>
      <h2>Create GRN</h2>
      <div>
        <label>Purchase Order:</label>
        <select value={purchaseOrderId} onChange={(e) => setPurchaseOrderId(e.target.value)} required>
          <option value="">Select PO</option>
          {purchaseOrders.map((po) => (
            <option key={po.id} value={po.id}>
              {po.id} - {po.supplierName}
            </option>
          ))}
        </select>
      </div>
      <div>
        <label>Received Date:</label>
        <input type="date" value={receivedDate} onChange={(e) => setReceivedDate(e.target.value)} required />
      </div>
      <div>
        <h3>Items</h3>
        {items.map((item, index) => (
          <div key={index}>
            <input
              type="number"
              placeholder="Product ID"
              value={item.productId}
              onChange={(e) => handleItemChange(index, "productId", e.target.value)}
              required
            />
            <input
              type="number"
              placeholder="Quantity"
              value={item.quantityReceived}
              onChange={(e) => handleItemChange(index, "quantityReceived", e.target.value)}
              required
            />
            {index > 0 && <button type="button" onClick={() => removeItem(index)}>Remove</button>}
          </div>
        ))}
        <button type="button" onClick={addItem}>Add Item</button>
      </div>
      <button type="submit">Create GRN</button>
    </form></center>
  );
};

export default GrnForm;
