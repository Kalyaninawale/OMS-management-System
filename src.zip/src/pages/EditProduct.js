// src/pages/products/EditProduct.js
import React, { useState, useEffect } from "react";
import { getProducts, updateProduct } from "../api";
import { useParams, useNavigate } from "react-router-dom";

export default function EditProduct() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState({});

  useEffect(() => {
    const fetchProduct = async () => {
      try {
        const response = await getProducts();
        const p = response.data.find((prod) => prod.id === parseInt(id));
        setProduct(p || {});
      } catch (error) {
        console.error("Error loading product:", error);
      }
    };
    fetchProduct();
  }, [id]);

  const handleChange = (e) => {
    setProduct({ ...product, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await updateProduct(id, product);
      navigate("/products");
    } catch (error) {
      console.error("Error updating product:", error);
    }
  };

  return (
    <center><div>
      <h2>Edit Product</h2>
      <form onSubmit={handleSubmit}>
        {Object.keys(product).map((key) => (
          <div key={key}>
            <label>{key}</label>
            <input
              type="text"
              name={key}
              value={product[key] || ""}
              onChange={handleChange}
            />
          </div>
        ))}
        <button type="submit">Update</button>
      </form>
    </div></center>
  );
}
