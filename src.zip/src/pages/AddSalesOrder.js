import React, { useEffect, useState } from "react";
import { fetchCustomers, createSalesOrder } from "../api";
import { useNavigate } from "react-router-dom";

export default function AddSalesOrder() {
  const [customers, setCustomers] = useState([]); // ✅ always start with array
  const [customerId, setCustomerId] = useState("");
  const [totalAmount, setTotalAmount] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetchCustomers()
      .then((res) => {
        // ✅ If paginated data from backend
        if (res.data.content) {
          setCustomers(res.data.content);
        } else if (Array.isArray(res.data)) {
          setCustomers(res.data);
        } else {
          setCustomers([]);
        }
      })
      .catch((err) => {
        console.error("Error fetching customers:", err);
        setCustomers([]); // ✅ fallback to empty array
      });
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    createSalesOrder({ customerId, totalAmount })
      .then(() => navigate("/sales-orders"))
      .catch((err) => console.error("Error creating sales order:", err));
  };

  return (
    <center><div>
      <h2>Add Sales Order</h2>
      <form onSubmit={handleSubmit}>
        <label>Customer:</label>
        <select value={customerId} onChange={(e) => setCustomerId(e.target.value)} required>
          <option value="">Select Customer</option>
          {customers.map((customer) => (
            <option key={customer.id} value={customer.id}>
              {customer.name}
            </option>
          ))}
        </select>

        <label>Total Amount:</label>
        <input
          type="number"
          value={totalAmount}
          onChange={(e) => setTotalAmount(e.target.value)}
          required
        />

        <button type="submit">Save</button>
      </form>
    </div></center>
  );
}
