import React, { useState } from "react";
import GrnForm from "../pages/GrnForm";
import GrnList from "../pages/GrnList";

const AddGRN = () => {
  const [refresh, setRefresh] = useState(false);

  return (
    <div>
      <GrnForm onGrnCreated={() => setRefresh(!refresh)} />
      <hr />
      <GrnList key={refresh} />
    </div>
  );
};

export default AddGRN;
