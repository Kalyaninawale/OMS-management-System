import React, { useState } from "react";
import { generateInvoice } from "../api";

const GenerateInvoice = () => {
  const [salesOrderId, setSalesOrderId] = useState("");
  const [invoice, setInvoice] = useState(null);

  const handleGenerate = async () => {
    try {
      const response = await generateInvoice(salesOrderId);
      setInvoice(response.data);
    } catch (error) {
      console.error("Error generating invoice:", error);
      alert("Failed to generate invoice. Check sales order ID.");
    }
  };

  return (
    <center>
    <div className="container">
      <h2>Generate Invoice from Sales Order</h2>
      <input
        type="number"
        placeholder="Enter Sales Order ID"
        value={salesOrderId}
        onChange={(e) => setSalesOrderId(e.target.value)}
      />
      <button onClick={handleGenerate}>Generate</button>

      {invoice && (
        <div style={{ marginTop: "20px" }}>
          <h3>Invoice Generated:</h3>
          <p><strong>Invoice ID:</strong> {invoice.id}</p>
          <p><strong>Invoice Date:</strong> {invoice.invoiceDate}</p>
          <p><strong>Status:</strong> {invoice.status}</p>
          <p><strong>Tax:</strong> {invoice.tax}%</p>
          <p><strong>Total Amount (with GST):</strong> {invoice.totalAmount}</p>

          <h4>Customer Details:</h4>
          <p><strong>Name:</strong> {invoice.customer?.name}</p>
          <p><strong>Email:</strong> {invoice.customer?.email}</p>
          <p><strong>Phone:</strong> {invoice.customer?.phone}</p>
          <p><strong>Address:</strong> {invoice.customer?.address}</p>
          <p><strong>GSTIN:</strong> {invoice.customer?.gstin}</p>

          {invoice.salesOrder && (
            <>
              <h4>Sales Order Details:</h4>
              <p><strong>Order ID:</strong> {invoice.salesOrder.id}</p>
              <p><strong>Order Date:</strong> {invoice.salesOrder.orderDate}</p>
              <p><strong>Status:</strong> {invoice.salesOrder.status}</p>

              <h5>Items:</h5>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th >Product Name</th>
                    <th>SKU</th>
                    <th>Category</th>
                    <th >Unit Price</th>
                    <th>Quantity</th>
                    <th>Price</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.salesOrder.items.map((item) => (
                    <tr key={item.id}>
                      <td >{item.product.productName}</td>
                      <td >{item.product.sku}</td>
                      <td>{item.product.category}</td>
                      <td>{item.product.unitPrice}</td>
                      <td>{item.quantity}</td>
                      <td>{item.price}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </div>
      )}
    </div></center>
  );
};

export default GenerateInvoice;
