import React, { useEffect, useState } from "react";
import { getAllInvoices } from "../api";

const ListInvoices = () => {
  const [invoices, setInvoices] = useState([]);

  useEffect(() => {
    fetchInvoices();
  }, []);

  const fetchInvoices = async () => {
    try {
      const response = await getAllInvoices();
      setInvoices(response.data);
    } catch (error) {
      console.error("Error fetching invoices:", error);
      alert("Failed to fetch invoices");
    }
  };

  return (
    <center><div className="container">
      <h2>Invoices</h2>
      <table border="1" cellPadding="10">
        <thead>
          <tr>
            <th>ID</th>
            <th>Customer</th>
            <th>SalesOrder ID</th>
            <th>Invoice Date</th>
            <th>Total Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {invoices.map((invoice) => (
            <tr key={invoice.id}>
              <td>{invoice.id}</td>
              <td>{invoice.customer?.name}</td>
              <td>{invoice.salesOrder?.id}</td>
              <td>{invoice.invoiceDate}</td>
              <td>{invoice.totalAmount}</td>
              <td>{invoice.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div></center>
  );
};

export default ListInvoices;
