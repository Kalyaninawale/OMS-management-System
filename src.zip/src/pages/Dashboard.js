import React from "react";
import { useNavigate } from "react-router-dom";
import './Dashboard.css';

const Dashboard = () => {
  const navigate = useNavigate();

  const pages = [
    { name: "Products", path: "/products" },
    { name: "Add Product", path: "/products/add" },
    { name: "Customers", path: "/customers" },
    { name: "Suppliers", path: "/suppliers" },
    { name: "Sales Orders", path: "/sales-orders" },
    { name: "Add Sales Order", path: "/add-sales-order" },
    { name: "Purchase Orders", path: "/purchase-orders" },
    { name: "GRN List", path: "/grns" },
    { name: "Add GRN", path: "/grns/add" },
    { name: "Generate Invoice", path: "/invoices/generate" },
    { name: "List Invoices", path: "/invoices" },
  ];

  return (
    <div className="dashboard-container">
      <div className="dashboard-grid">
        <h2>ORNAMENTS SYSTEM</h2>
        {pages.map((page, index) => (
          <div
            key={index}
            className="dashboard-card"
            onClick={() => navigate(page.path)}
          >
            <h3>{page.name}</h3>
          </div>
        ))}
      </div>

      <div className="main-content">
        WELCOME TO ORNAMENTS MANAGEMENT SYSTEM
      </div>
    </div>
  );
};

export default Dashboard;
