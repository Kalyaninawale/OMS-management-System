import React, { useEffect, useState } from "react";
import API from "../api";

const GrnList = () => {
  const [grns, setGrns] = useState([]);

  useEffect(() => {
    API.get("/grns")
      .then((res) => setGrns(res.data))
      .catch((err) => console.error(err));
  }, []);

  return (
    <center>
    <div>
      <h2>All GRNs</h2>
      <table border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Received Date</th>
            <th>Purchase Order</th>
            <th>Items</th>
          </tr>
        </thead>
        <tbody>
          {grns.map((grn) => (
            <tr key={grn.id}>
              <td>{grn.id}</td>
              <td>{grn.receivedDate}</td>
              <td>{grn.purchaseOrderId}</td>
              <td>
                {grn.items.map((i, idx) => (
                  <div key={idx}>
                    {i.productName} - {i.quantityReceived} (Stock: {i.currentStock})
                  </div>
                ))}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div></center>
  );
};

export default GrnList;
