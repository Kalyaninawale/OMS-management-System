// src/pages/products/ProductList.js
import React, { useEffect, useState } from "react";
import { getProducts, deleteProduct } from "../api";
import { useNavigate } from "react-router-dom";

export default function ProductList() {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
    try {
      const response = await getProducts();
      setProducts(response.data);
    } catch (error) {
      console.error("Error loading products:", error);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this product?")) {
      try {
        await deleteProduct(id);
        loadProducts();
      } catch (error) {
        console.error("Error deleting product:", error);
      }
    }
  };

  return (
    <center><div>
      <h2>Products</h2>
      <button onClick={() => navigate("/products/add")}>Add Product</button>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>Name</th>
            <th>SKU</th>
            <th>Category</th>
            <th>Unit Price</th>
            <th>Stock</th>
            <th>Reorder Level</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.map((p) => (
            <tr key={p.id}>
              <td>{p.productName}</td>
              <td>{p.sku}</td>
              <td>{p.category}</td>
              <td>{p.unitPrice}</td>
              <td>{p.currentStock}</td>
              <td>{p.reorderLevel}</td>
              <td>
                <button onClick={() => navigate(`/products/edit/${p.id}`)}>Edit</button>
                <button onClick={() => handleDelete(p.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div></center>
  );
}
