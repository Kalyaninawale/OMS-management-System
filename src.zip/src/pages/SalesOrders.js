import React, { useEffect, useState } from "react";
import { fetchSalesOrders } from "../api";
import '../App.css';
const SalesOrders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const response = await fetchSalesOrders();
      console.log("Sales Orders Response:", response.data);
      setOrders(response.data.content || response.data);
    } catch (error) {
      console.error("Error fetching sales orders:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <p>Loading sales orders...</p>;

  return (
    <center><div>
      <h2>
        Sales Orders
      </h2>
      {orders.length === 0 ? (
        <p>No sales orders found.</p>
      ) : (
        <div style={{ overflowX: "auto" }}>
          <table
            style={{
              width: "100%",
              borderCollapse: "collapse",
              textAlign: "center",
            }}
          >
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Items</th>
                <th>Order Date</th>
                <th>Status</th>
                <th>Total Amount</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => (
                <tr key={order.id} >
                  <td>{order.id}</td>
                  <td>{order.customer?.name}</td>
                  <td>
                    <ul>
                      {order.items?.map((item) => (
                        <li key={item.id}>
                          {item.product?.productName} × {item.quantity} @ ₹
                          {item.price}
                        </li>
                      ))}
                    </ul>
                  </td>
                  <td>{order.orderDate}</td>
                  <td>{order.status}</td>
                  <td>₹{order.totalAmount}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div></center>
  );
};

// ✅ Common styles

export default SalesOrders;
