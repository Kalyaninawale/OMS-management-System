import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

import Register from './pages/Register';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';

import ProductList from './pages/ProductList';
import AddProduct from './pages/AddProduct';
import EditProduct from './pages/EditProduct';

import Customers from './pages/Customers';
import Suppliers from './pages/Suppliers';

import SalesOrders from './pages/SalesOrders';
import AddSalesOrder from './pages/AddSalesOrder';

import PurchaseOrders from './pages/PurchaseOrders';

import GRNList from './pages/GrnList';
import AddGRN from './pages/AddGRN';

import ListInvoices from './pages/ListInvoices';
import GenerateInvoice from './pages/GenerateInvoice';

import ProtectedRoute from './ProtectedRoute';

function App() {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Navigate to="/login" />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />

        {/* Protected Routes */}
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        {/* Products */}
        <Route
          path="/products"
          element={
            <ProtectedRoute>
              <ProductList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/products/add"
          element={
            <ProtectedRoute>
              <AddProduct />
            </ProtectedRoute>
          }
        />
        <Route
          path="/products/edit/:id"
          element={
            <ProtectedRoute>
              <EditProduct />
            </ProtectedRoute>
          }
        />

        {/* Customers */}
        <Route
          path="/customers"
          element={
            <ProtectedRoute>
              <Customers />
            </ProtectedRoute>
          }
        />

        {/* Suppliers */}
        <Route
          path="/suppliers"
          element={
            <ProtectedRoute>
              <Suppliers />
            </ProtectedRoute>
          }
        />

        {/* Sales Orders */}
        <Route
          path="/sales-orders"
          element={
            <ProtectedRoute>
              <SalesOrders />
            </ProtectedRoute>
          }
        />
        <Route
          path="/add-sales-order"
          element={
            <ProtectedRoute>
              <AddSalesOrder />
            </ProtectedRoute>
          }
        />

        {/* Purchase Orders */}
        <Route
          path="/purchase-orders"
          element={
            <ProtectedRoute>
              <PurchaseOrders />
            </ProtectedRoute>
          }
        />

        {/* GRN Routes */}
        <Route
          path="/grns"
          element={
            <ProtectedRoute>
              <GRNList />
            </ProtectedRoute>
          }
        />
        <Route
          path="/grns/add"
          element={
            <ProtectedRoute>
              <AddGRN />
            </ProtectedRoute>
          }
        />

        {/* Invoice Routes */}
        <Route
          path="/invoices"
          element={
            <ProtectedRoute>
              <ListInvoices />
            </ProtectedRoute>
          }
        />

        <Route
  path="/dashboard"
  element={
    <ProtectedRoute>
      <Dashboard />
    </ProtectedRoute>
  }
/>

        <Route
          path="/invoices/generate"
          element={
            <ProtectedRoute>
              <GenerateInvoice />
            </ProtectedRoute>
          }
        />

        {/* Optional 404 Page */}
        <Route path="*" element={<div>Page Not Found</div>} />
      </Routes>
    </Router>
  );
}

export default App;
