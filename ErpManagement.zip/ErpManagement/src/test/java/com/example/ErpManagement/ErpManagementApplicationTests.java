package com.example.ErpManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ErpManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
