package com.example.ErpManagement_Repository;


import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ErpManagement_Entity.PurchaseOrder;

public interface PurchaseOrderRepository extends JpaRepository<PurchaseOrder, Long> {
	List<PurchaseOrder> findByExpectedDeliveryDateBetween(LocalDate start, LocalDate end);

}