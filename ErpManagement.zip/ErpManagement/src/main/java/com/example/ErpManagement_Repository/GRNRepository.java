package com.example.ErpManagement_Repository;


import com.example.ErpManagement_Entity.GRN;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GRNRepository extends JpaRepository<GRN, Long> {
}
