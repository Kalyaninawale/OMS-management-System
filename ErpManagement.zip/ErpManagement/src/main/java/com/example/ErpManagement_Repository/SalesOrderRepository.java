package com.example.ErpManagement_Repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ErpManagement_Entity.SalesOrder;
import com.example.ErpManagement_Entity.SalesOrderStatus;

@Repository
public interface SalesOrderRepository extends JpaRepository<SalesOrder, Long> {
    List<SalesOrder> findByStatus(SalesOrderStatus status);
    List<SalesOrder> findByOrderDateBetween(LocalDate start, LocalDate end);

}
