package com.example.ErpManagement_Controller;
import com.example.ErpManagement_Dto.GRNRequest;
import com.example.ErpManagement_Dto.GRNResponse;
import com.example.ErpManagement_Services.GRNService;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/grns")
public class GRNController {

    private final GRNService grnService;

    public GRNController(GRNService grnService) {
        this.grnService = grnService;
    }

    @PostMapping
    public GRNResponse createGRN(@RequestBody GRNRequest request) {
        return grnService.createGRN(request);
    }

    @GetMapping
    public List<GRNResponse> getAllGRNs() {
        return grnService.getAllGRNs();
    }
}