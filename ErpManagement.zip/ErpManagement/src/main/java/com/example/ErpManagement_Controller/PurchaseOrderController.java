package com.example.ErpManagement_Controller;

import com.example.ErpManagement_Dto.PurchaseOrderResponse;
import com.example.ErpManagement_Entity.PurchaseOrder;
import com.example.ErpManagement_Services.PurchaseOrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/purchase-orders")
public class PurchaseOrderController {

    private final PurchaseOrderService purchaseOrderService;

    public PurchaseOrderController(PurchaseOrderService purchaseOrderService) {
        this.purchaseOrderService = purchaseOrderService;
    }

    // ✅ Get all purchase orders
    @GetMapping
    public ResponseEntity<List<PurchaseOrderResponse>> getAllPurchaseOrders() {
        return ResponseEntity.ok(purchaseOrderService.getAllPurchaseOrders());
    }

    // ✅ Get purchase order by id
    @GetMapping("/{id}")
    public ResponseEntity<PurchaseOrderResponse> getPurchaseOrderById(@PathVariable Long id) {
        PurchaseOrder order = purchaseOrderService.getPurchaseOrderById(id);
        return ResponseEntity.ok(purchaseOrderService.mapToResponse(order));
    }

    // ✅ Create a new purchase order
    @PostMapping
    public ResponseEntity<PurchaseOrderResponse> createPurchaseOrder(@RequestBody PurchaseOrder purchaseOrder) {
        PurchaseOrder savedOrder = purchaseOrderService.savePurchaseOrder(purchaseOrder);
        return ResponseEntity.ok(purchaseOrderService.mapToResponse(savedOrder));
    }

    // ✅ Update status of a purchase order (example: ORDERED → RECEIVED)
    @PutMapping("/{id}/status")
    public ResponseEntity<PurchaseOrderResponse> updateStatus(@PathVariable Long id,
                                                              @RequestParam PurchaseOrder.Status status) {
        PurchaseOrder updatedOrder = purchaseOrderService.updateStatus(id, status);
        return ResponseEntity.ok(purchaseOrderService.mapToResponse(updatedOrder));
    }

    // ✅ Delete a purchase order
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePurchaseOrder(@PathVariable Long id) {
        purchaseOrderService.deletePurchaseOrder(id);
        return ResponseEntity.noContent().build();
    }
}
