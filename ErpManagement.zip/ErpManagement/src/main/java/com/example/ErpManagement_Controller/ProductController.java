package com.example.ErpManagement_Controller;

import com.example.ErpManagement_Entity.Product;
import com.example.ErpManagement_Dto.ProductRequest;
import com.example.ErpManagement_Dto.ProductResponse;
import com.example.ErpManagement_Services.ProductService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.HttpStatus;
import jakarta.validation.Valid;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "http://localhost:3000") // adjust your frontend origin
public class ProductController {

    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    // GET /api/products
    @GetMapping
    public ResponseEntity<List<ProductResponse>> getAll() {
        List<ProductResponse> list = service.getAllProducts()
                .stream()
                .map(this::toResponse)
                .collect(Collectors.toList());
        return ResponseEntity.ok(list);
    }

    // GET /api/products/{id}
    @GetMapping("/{id}")
    public ResponseEntity<ProductResponse> getById(@PathVariable Long id) {
        Product p = service.getById(id);
        return ResponseEntity.ok(toResponse(p));
    }

    // POST /api/products
    @PostMapping
    public ResponseEntity<ProductResponse> create(@Valid @RequestBody ProductRequest req) {
        Product p = toEntity(req);
        Product saved = service.createProduct(p);
        return ResponseEntity.status(HttpStatus.CREATED).body(toResponse(saved));
    }

    // PUT /api/products/{id}
    @PutMapping("/{id}")
    public ResponseEntity<ProductResponse> update(@PathVariable Long id, @Valid @RequestBody ProductRequest req) {
        Product p = toEntity(req);
        Product updated = service.updateProduct(id, p);
        return ResponseEntity.ok(toResponse(updated));
    }

    // DELETE /api/products/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteProduct(id);
        return ResponseEntity.noContent().build();
    }

    // ---- simple mappers ----
    private ProductResponse toResponse(Product p) {
        return ProductResponse.builder()
                .id(p.getId())
                .productName(p.getProductName())
                .sku(p.getSku())
                .category(p.getCategory())
                .unitPrice(p.getUnitPrice())
                .currentStock(p.getCurrentStock())
                .reorderLevel(p.getReorderLevel())
                .build();
    }

    private Product toEntity(ProductRequest req) {
        return Product.builder()
                .productName(req.getProductName())
                .sku(req.getSku())
                .category(req.getCategory())
                .unitPrice(req.getUnitPrice())
                .currentStock(req.getCurrentStock())
                .reorderLevel(req.getReorderLevel())
                .build();
    }
}
