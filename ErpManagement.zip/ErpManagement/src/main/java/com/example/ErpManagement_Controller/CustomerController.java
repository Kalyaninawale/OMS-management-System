package com.example.ErpManagement_Controller;

import com.example.ErpManagement_Dto.CustomerDTO;
import com.example.ErpManagement_Services.CustomerService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService service;

    public CustomerController(CustomerService service) {
        this.service = service;
    }

    @Operation(summary = "Get paginated list of customers")
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','SALES_EXECUTIVE')")
    public ResponseEntity<Page<CustomerDTO>> getAllCustomers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());
        return ResponseEntity.ok(service.getAllCustomers(pageable));
    }

    @Operation(summary = "Create a new customer")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','SALES_EXECUTIVE')")
    public ResponseEntity<CustomerDTO> createCustomer(@Valid @RequestBody CustomerDTO dto) {
        CustomerDTO created = service.createCustomer(dto);
        return ResponseEntity.status(201).body(created);
    }

    @Operation(summary = "Update customer details")
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','SALES_EXECUTIVE')")
    public ResponseEntity<CustomerDTO> updateCustomer(
            @PathVariable Long id,
            @Valid @RequestBody CustomerDTO dto
    ) {
        CustomerDTO updated = service.updateCustomer(id, dto);
        return ResponseEntity.ok(updated);
    }

    @Operation(summary = "Delete a customer")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteCustomer(@PathVariable Long id) {
        service.deleteCustomer(id);
        return ResponseEntity.noContent().build();
    }
}
