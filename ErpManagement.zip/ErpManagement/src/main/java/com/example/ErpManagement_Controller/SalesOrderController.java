package com.example.ErpManagement_Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.example.ErpManagement_Dto.SalesOrderDto;
import com.example.ErpManagement_Entity.SalesOrder;
import com.example.ErpManagement_Entity.SalesOrderStatus;
import com.example.ErpManagement_Services.SalesOrderService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/sales-orders")
@PreAuthorize("hasAnyRole('ADMIN','SALES_EXECUTIVE')")
public class SalesOrderController {

    @Autowired
    private SalesOrderService salesOrderService;

    @GetMapping
    public List<SalesOrder> getAllSalesOrders() {
        return salesOrderService.getAllSalesOrders();
    }

    @PostMapping
    public ResponseEntity<SalesOrder> createSalesOrder(@RequestBody @Valid SalesOrderDto dto) {
        SalesOrder savedOrder = salesOrderService.createSalesOrder(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedOrder);
    }

    @PutMapping("/{id}/status")
    public ResponseEntity<SalesOrder> updateStatus(@PathVariable Long id,
        @RequestParam SalesOrderStatus status) {
        SalesOrder updatedOrder = salesOrderService.updateStatus(id, status);
        return ResponseEntity.ok(updatedOrder);
    }
}
