package com.example.ErpManagement_Controller;


import com.example.ErpManagement_Dto.SupplierDTO;
import com.example.ErpManagement_Services.SupplierService;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/suppliers")
public class SupplierController {

    private final SupplierService service;

    public SupplierController(SupplierService service) {
        this.service = service;
    }

    @Operation(summary = "Get paginated list of supplier")
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','PURCHASE_MANAGER')")
    public ResponseEntity<Page<SupplierDTO>> getAllSupplier(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());
        return ResponseEntity.ok(service.getAllSupplier(pageable));
    }

    @Operation(summary = "Create a new supplier")
    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','PURCHASE_MANAGER')")
    public ResponseEntity<SupplierDTO> createSupplier(@Valid @RequestBody SupplierDTO dto) {
    	SupplierDTO created = service.createSupplier(dto);
        return ResponseEntity.status(201).body(created);
    }

    @Operation(summary = "Update supplier details")
    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','PURCHASE_MANAGER')")
    public ResponseEntity<SupplierDTO> updateSupplier(
            @PathVariable Long id,
            @Valid @RequestBody SupplierDTO dto
    ) {
    	SupplierDTO updated = service.updateSupplier(id, dto);
        return ResponseEntity.ok(updated);
    }

    @Operation(summary = "Delete a Supplier")
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> deleteSupplier(@PathVariable Long id) {
        service.deleteSupplier(id);
        return ResponseEntity.noContent().build();
    }
}
