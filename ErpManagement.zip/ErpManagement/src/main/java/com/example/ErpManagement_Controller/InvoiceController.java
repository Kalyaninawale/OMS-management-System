package com.example.ErpManagement_Controller;

import com.example.ErpManagement_Entity.Invoice;
import com.example.ErpManagement_Entity.SalesOrder;
import com.example.ErpManagement_Services.InvoiceService;
import com.example.ErpManagement_Services.SalesOrderService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.ErpManagement_Services.InvoicePDFGenerator;
import java.util.List;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceController {

    private final InvoiceService invoiceService;
    private final SalesOrderService salesOrderService;

    public InvoiceController(InvoiceService invoiceService, SalesOrderService salesOrderService) {
        this.invoiceService = invoiceService;
        this.salesOrderService = salesOrderService;
    }

    @GetMapping
    public ResponseEntity<List<Invoice>> getAllInvoices() {
        return ResponseEntity.ok(invoiceService.getAllInvoices());
    }

    @PostMapping("/generate/{salesOrderId}")
    public ResponseEntity<Invoice> generateInvoice(@PathVariable Long salesOrderId) {
        SalesOrder salesOrder = salesOrderService.getSalesOrderById(salesOrderId);
        Invoice invoice = invoiceService.generateInvoiceFromSalesOrder(salesOrder);
        return ResponseEntity.ok(invoice);
    }

    @GetMapping("/{id}/pdf")
    public ResponseEntity<byte[]> generateInvoicePDF(@PathVariable Long id) {
        // PDF logic
        Invoice invoice = invoiceService.getInvoiceById(id);

        byte[] pdfBytes = InvoicePDFGenerator.generate(invoice); // We'll create next
        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=invoice_" + id + ".pdf")
                .contentType(org.springframework.http.MediaType.APPLICATION_PDF)
                .body(pdfBytes);
    }
}
