package com.example.ErpManagement_Controller;

import com.example.ErpManagement_Services.DashboardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @Autowired
    private DashboardService dashboardService;

    @GetMapping("/sales-summary")
    public ResponseEntity<Map<String, Object>> getSalesSummary() {
        return ResponseEntity.ok(dashboardService.getSalesSummary());
    }

    @GetMapping("/purchase-summary")
    public ResponseEntity<Map<String, Object>> getPurchaseSummary() {
        return ResponseEntity.ok(dashboardService.getPurchaseSummary());
    }

    @GetMapping("/stock-alerts")
    public ResponseEntity<Map<String, Object>> getStockAlerts() {
        return ResponseEntity.ok(dashboardService.getStockAlerts());
    }

    @GetMapping("/pending-invoices")
    public ResponseEntity<Map<String, Object>> getPendingInvoices() {
        return ResponseEntity.ok(dashboardService.getPendingInvoices());
    }
}
