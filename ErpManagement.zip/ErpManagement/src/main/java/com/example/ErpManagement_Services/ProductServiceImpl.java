package com.example.ErpManagement_Services;

import com.example.ErpManagement_Entity.Product;
import com.example.ErpManagement_Repository.ProductRepository;
import com.example.ErpManagement_Exception.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Random;

@Service
@Transactional
public class ProductServiceImpl implements ProductService {

    private final ProductRepository repo;
    private final Random random = new Random();

    public ProductServiceImpl(ProductRepository repo) {
        this.repo = repo;
    }

    @Override
    public List<Product> getAllProducts() {
        return repo.findAll();
    }

    @Override
    public Product getById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
    }

    @Override
    public Product createProduct(Product product) {
        if (product.getSku() == null || product.getSku().isBlank()) {
            product.setSku(generateSku());
        } else {
            // optional: ensure SKU unique
            repo.findBySku(product.getSku()).ifPresent(existing -> {
                throw new IllegalArgumentException("SKU already exists: " + product.getSku());
            });
        }
        return repo.save(product);
    }

    @Override
    public Product updateProduct(Long id, Product updated) {
        Product existing = getById(id);
        // if user passes new SKU, check uniqueness (and allow same SKU if unchanged)
        String newSku = updated.getSku();
        if (newSku != null && !newSku.isBlank() && !newSku.equals(existing.getSku())) {
            repo.findBySku(newSku).ifPresent(p -> {
                throw new IllegalArgumentException("SKU already exists: " + newSku);
            });
            existing.setSku(newSku);
        }
        existing.setProductName(updated.getProductName());
        existing.setCategory(updated.getCategory());
        existing.setUnitPrice(updated.getUnitPrice());
        existing.setCurrentStock(updated.getCurrentStock());
        existing.setReorderLevel(updated.getReorderLevel());
        return repo.save(existing);
    }

    @Override
    public void deleteProduct(Long id) {
        if (!repo.existsById(id)) {
            throw new ResourceNotFoundException("Product not found with id: " + id);
        }
        repo.deleteById(id);
    }

    private String generateSku() {
        String date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        int r = random.nextInt(900) + 100; // 100..999
        return "PRD-" + date + "-" + r;
    }
}
