package com.example.ErpManagement_Services;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;


import com.example.ErpManagement_Dto.SupplierDTO;

public interface SupplierService {
    Page<SupplierDTO> getAllSupplier(Pageable pageable);
    SupplierDTO getSupplierById(Long id);
    SupplierDTO createSupplier(SupplierDTO dto);
    SupplierDTO updateSupplier(Long id, SupplierDTO dto);
    void deleteSupplier(Long id);
}
