package com.example.ErpManagement_Services;

import com.example.ErpManagement_Entity.Invoice;
import com.example.ErpManagement_Entity.SalesOrder;

import java.util.List;

public interface InvoiceService {

    List<Invoice> getAllInvoices();

    Invoice generateInvoiceFromSalesOrder(SalesOrder salesOrder);
    Invoice saveInvoice(Invoice invoice);   // ✅ Add this
    Invoice getInvoiceById(Long id);
}
