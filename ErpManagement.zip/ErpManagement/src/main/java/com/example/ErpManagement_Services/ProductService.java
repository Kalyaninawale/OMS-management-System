package com.example.ErpManagement_Services;

import com.example.ErpManagement_Entity.Product;
import java.util.List;

public interface ProductService {
    List<Product> getAllProducts();
    Product getById(Long id);
    Product createProduct(Product product);
    Product updateProduct(Long id, Product product);
    void deleteProduct(Long id);
}
