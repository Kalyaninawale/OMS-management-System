package com.example.ErpManagement_Services;

import com.example.ErpManagement_Entity.Invoice;
import com.example.ErpManagement_Entity.SalesOrder;
import com.example.ErpManagement_Repository.InvoiceRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class InvoiceServiceImpl implements InvoiceService {

    private final InvoiceRepository invoiceRepository;

    public InvoiceServiceImpl(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    @Override
    public List<Invoice> getAllInvoices() {
        return invoiceRepository.findAll();
    }

    @Override
    public Invoice getInvoiceById(Long id) {
        return invoiceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Invoice not found with id: " + id));
    }

    @Override
    public Invoice saveInvoice(Invoice invoice) {
        return invoiceRepository.save(invoice);
    }

    @Override
    public Invoice generateInvoiceFromSalesOrder(SalesOrder salesOrder) {
        Invoice invoice = new Invoice();
        invoice.setCustomer(salesOrder.getCustomer());
        invoice.setSalesOrder(salesOrder);
        invoice.setInvoiceDate(LocalDate.now());
        invoice.setTax(18.0); // default GST

        // --- BigDecimal multiplication for totalAmount ---
        BigDecimal totalAmount = salesOrder.getTotalAmount(); // must be BigDecimal
        BigDecimal gstMultiplier = new BigDecimal("1.18"); // 18% GST
        BigDecimal totalWithGST = totalAmount.multiply(gstMultiplier).setScale(2, BigDecimal.ROUND_HALF_UP);

        invoice.setTotalAmount(totalWithGST); // now works perfectly

        invoice.setStatus("UNPAID");
        return invoiceRepository.save(invoice);
    }
}
