package com.example.ErpManagement_Services;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.ErpManagement_Dto.SalesOrderDto;
import com.example.ErpManagement_Dto.SalesOrderItemDto;
import com.example.ErpManagement_Entity.*;
import com.example.ErpManagement_Repository.CustomerRepository;
import com.example.ErpManagement_Repository.ProductRepository;
import com.example.ErpManagement_Repository.SalesOrderRepository;
@Service
public class SalesOrderService {

    @Autowired
    private SalesOrderRepository salesOrderRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Transactional
    public SalesOrder createSalesOrder(SalesOrderDto dto) {
        Customer customer = customerRepository.findById(dto.getCustomerId())
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        SalesOrder order = new SalesOrder();
        order.setCustomer(customer);
        order.setOrderDate(LocalDate.now());
        order.setStatus(SalesOrderStatus.PENDING);

        List<SalesOrderItem> items = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;

        for (SalesOrderItemDto itemDto : dto.getItems()) {
            Product product = productRepository.findById(itemDto.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

            SalesOrderItem item = new SalesOrderItem();
            item.setSalesOrder(order);
            item.setProduct(product);
            item.setQuantity(itemDto.getQuantity());
            item.setPrice(BigDecimal.valueOf(product.getUnitPrice()));

            BigDecimal price = BigDecimal.valueOf(product.getUnitPrice());
            BigDecimal quantity = BigDecimal.valueOf(itemDto.getQuantity());

            total = total.add(price.multiply(quantity));

            items.add(item);
        }

        order.setItems(items);
        order.setTotalAmount(total);

        return salesOrderRepository.save(order);
    }

    public List<SalesOrder> getAllSalesOrders() {
        return salesOrderRepository.findAll();
    }

    public SalesOrder updateStatus(Long id, SalesOrderStatus status) {
        SalesOrder order = salesOrderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(status);
        return salesOrderRepository.save(order);
    }

    // ✅ Add this method
    public SalesOrder getSalesOrderById(Long id) {
        return salesOrderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Sales order not found with id: " + id));
    }
}
