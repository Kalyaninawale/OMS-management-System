package com.example.ErpManagement_Services;


import com.example.ErpManagement_Dto.CustomerDTO;
import com.example.ErpManagement_Entity.Customer;
import com.example.ErpManagement_Repository.CustomerRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository repo;

    @Autowired
    private ModelMapper mapper;

    @Override
    public Page<CustomerDTO> getAllCustomers(Pageable pageable) {
        Page<Customer> page = repo.findAll(pageable);
        return page.map(customer -> mapper.map(customer, CustomerDTO.class));
    }

    @Override
    public CustomerDTO getCustomerById(Long id) {
        Customer customer = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id " + id));
        return mapper.map(customer, CustomerDTO.class);
    }

    @Override
    public CustomerDTO createCustomer(CustomerDTO dto) {
        Customer customer = mapper.map(dto, Customer.class);
        Customer saved = repo.save(customer);
        return mapper.map(saved, CustomerDTO.class);
    }

    @Override
    public CustomerDTO updateCustomer(Long id, CustomerDTO dto) {
        Customer existing = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id " + id));

        existing.setName(dto.getName());
        existing.setEmail(dto.getEmail());
        existing.setPhone(dto.getPhone());
        existing.setAddress(dto.getAddress());
        existing.setGstin(dto.getGstin());

        Customer updated = repo.save(existing);
        return mapper.map(updated, CustomerDTO.class);
    }

    @Override
    public void deleteCustomer(Long id) {
        Customer existing = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Customer not found with id " + id));
        repo.delete(existing);
    }
}
