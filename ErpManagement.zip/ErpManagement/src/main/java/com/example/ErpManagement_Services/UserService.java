package com.example.ErpManagement_Services;

import com.example.ErpManagement_Entity.User;
import java.util.List;

public interface UserService {
    User register(User user);
    String login(String username, String password);
    List<User> getAllUsers(); // ✅ Added
}
