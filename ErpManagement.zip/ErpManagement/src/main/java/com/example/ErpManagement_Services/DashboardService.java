package com.example.ErpManagement_Services;

import com.example.ErpManagement_Entity.*;
import com.example.ErpManagement_Repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;

@Service
public class DashboardService {

    @Autowired
    private SalesOrderRepository salesOrderRepo;

    @Autowired
    private PurchaseOrderRepository purchaseOrderRepo;

    @Autowired
    private ProductRepository productRepo;

    @Autowired
    private InvoiceRepository invoiceRepo;

    // 1️⃣ Total Sales This Month
    public Map<String, Object> getSalesSummary() {
        LocalDate start = LocalDate.now().withDayOfMonth(1);
        LocalDate end = LocalDate.now();

        BigDecimal totalSales = salesOrderRepo.findByOrderDateBetween(start, end)
            .stream()
            .map(SalesOrder::getTotalAmount)
            .reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<String, Object> result = new HashMap<>();
        result.put("totalSalesThisMonth", totalSales);
        return result;
    }

    // 2️⃣ Total Purchases This Month (safe for-loop)
    public Map<String, Object> getPurchaseSummary() {
        LocalDate start = LocalDate.now().withDayOfMonth(1);
        LocalDate end = LocalDate.now();

        BigDecimal totalPurchases = BigDecimal.ZERO;

        List<PurchaseOrder> orders = purchaseOrderRepo.findByExpectedDeliveryDateBetween(start, end);

        for (PurchaseOrder po : orders) {
            if (po.getItems() == null) continue;

            for (PurchaseOrderItem item : po.getItems()) {
                Double price = item.getProduct().getUnitPrice(); // Double from entity
                BigDecimal unitPrice = price == null ? BigDecimal.ZERO : BigDecimal.valueOf(price);
                BigDecimal quantity = BigDecimal.valueOf(item.getQuantity());

                totalPurchases = totalPurchases.add(unitPrice.multiply(quantity));
            }
        }


        Map<String, Object> result = new HashMap<>();
        result.put("totalPurchasesThisMonth", totalPurchases);
        return result;
    }

    // 3️⃣ Low Stock Alerts
    public Map<String, Object> getStockAlerts() {
        List<Product> lowStock = productRepo.findAll().stream()
            .filter(p -> p.getCurrentStock() <= p.getReorderLevel())
            .toList();

        Map<String, Object> result = new HashMap<>();
        result.put("lowStockProducts", lowStock);
        return result;
    }

    // 4️⃣ Pending Invoices
    public Map<String, Object> getPendingInvoices() {
        List<Invoice> pendingInvoices = invoiceRepo.findByStatus("UNPAID");

        Map<String, Object> result = new HashMap<>();
        result.put("pendingInvoices", pendingInvoices);
        return result;
    }
}
