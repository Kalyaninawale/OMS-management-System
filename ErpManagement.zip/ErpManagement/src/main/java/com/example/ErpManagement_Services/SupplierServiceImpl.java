package com.example.ErpManagement_Services;




import com.example.ErpManagement_Dto.SupplierDTO;

import com.example.ErpManagement_Entity.Supplier;
import com.example.ErpManagement_Repository.SupplierRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

@Service
public class SupplierServiceImpl implements SupplierService {

    @Autowired
    private SupplierRepository repo;

    @Autowired
    private ModelMapper mapper;

    @Override
    public Page<SupplierDTO> getAllSupplier(Pageable pageable) {
        Page<Supplier> page = repo.findAll(pageable);
        return page.map(supplier -> mapper.map(supplier, SupplierDTO.class));
    }

    @Override
    public SupplierDTO getSupplierById(Long id) {
        Supplier supplier = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Supplier not found with id " + id));
        return mapper.map(supplier , SupplierDTO.class);
    }

    @Override
    public SupplierDTO createSupplier(SupplierDTO dto) {
        Supplier supplier = mapper.map(dto, Supplier.class);
        Supplier saved = repo.save(supplier);
        return mapper.map(saved, SupplierDTO.class);
    }

    @Override
    public SupplierDTO updateSupplier(Long id, SupplierDTO dto) {
        Supplier existing = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Supplier not found with id " + id));

        existing.setName(dto.getName());
        existing.setEmail(dto.getEmail());
        existing.setPhone(dto.getPhone());
        existing.setAddress(dto.getAddress());
        existing.setGstin(dto.getGstin());

        Supplier updated = repo.save(existing);
        return mapper.map(updated, SupplierDTO.class);
    }

    @Override
    public void deleteSupplier(Long id) {
        Supplier existing = repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Supplier not found with id " + id));
        repo.delete(existing);
    }
}
