package com.example.ErpManagement_Services;

import com.example.ErpManagement_Dto.GRNRequest;
import com.example.ErpManagement_Dto.GRNResponse;
import com.example.ErpManagement_Entity.GRN;
import com.example.ErpManagement_Entity.GRNItem;
import com.example.ErpManagement_Entity.Product;
import com.example.ErpManagement_Entity.PurchaseOrder;
import com.example.ErpManagement_Repository.GRNRepository;
import com.example.ErpManagement_Repository.ProductRepository;
import com.example.ErpManagement_Repository.PurchaseOrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.stream.Collectors;
import java.util.List;

@Service
public class GRNService {

    private final GRNRepository grnRepository;
    private final PurchaseOrderRepository purchaseOrderRepository;
    private final ProductRepository productRepository;

    public GRNService(GRNRepository grnRepository,
                      PurchaseOrderRepository purchaseOrderRepository,
                      ProductRepository productRepository) {
        this.grnRepository = grnRepository;
        this.purchaseOrderRepository = purchaseOrderRepository;
        this.productRepository = productRepository;
    }

    /**
     * Create a new GRN and update stock
     */
    @Transactional
    public GRNResponse createGRN(GRNRequest request) {
        // get purchase order
        PurchaseOrder po = purchaseOrderRepository.findById(request.getPurchaseOrderId())
                .orElseThrow(() -> new RuntimeException("Purchase Order not found"));

        // create GRN entity
        GRN grn = new GRN();
        grn.setReceivedDate(request.getReceivedDate());
        grn.setPurchaseOrder(po);

        // map items from request -> entity
        grn.setItems(request.getItems().stream().map(itemReq -> {
            Product product = productRepository.findById(itemReq.getProductId())
                    .orElseThrow(() -> new RuntimeException("Product not found"));

            // update stock
            Integer currentStock = product.getCurrentStock() != null ? product.getCurrentStock() : 0;
            product.setCurrentStock(currentStock + itemReq.getQuantityReceived());
            productRepository.save(product);

            // create GRNItem
            GRNItem item = new GRNItem();
            item.setGrn(grn);
            item.setProduct(product);
            item.setQuantityReceived(itemReq.getQuantityReceived());
            return item;
        }).collect(Collectors.toList()));

        GRN saved = grnRepository.save(grn);
        return toResponse(saved);
    }

    /**
     * Get all GRNs
     */
    public List<GRNResponse> getAllGRNs() {
        return grnRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    /**
     * Convert GRN entity -> Response DTO
     */
    private GRNResponse toResponse(GRN grn) {
        GRNResponse res = new GRNResponse();
        res.setId(grn.getId());
        res.setReceivedDate(grn.getReceivedDate());
        res.setPurchaseOrderId(grn.getPurchaseOrder().getId());

        res.setItems(grn.getItems().stream().map(i -> {
            GRNResponse.GRNItemResponse itemRes = new GRNResponse.GRNItemResponse();
            itemRes.setProductName(i.getProduct().getProductName());
            itemRes.setQuantityReceived(i.getQuantityReceived());
            itemRes.setCurrentStock(i.getProduct().getCurrentStock()); // ✅ Added currentStock in response
            return itemRes;
        }).collect(Collectors.toList()));

        return res;
    }
}
