package com.example.ErpManagement_Services;
import org.springframework.stereotype.Service;
import java.util.Optional;
import com.example.ErpManagement_Dto.PurchaseOrderItemResponse;
import com.example.ErpManagement_Dto.PurchaseOrderResponse;
import com.example.ErpManagement_Dto.SupplierResponse;
import com.example.ErpManagement_Entity.PurchaseOrder;
import com.example.ErpManagement_Repository.PurchaseOrderRepository;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PurchaseOrderService {

	
	
	 private final PurchaseOrderRepository purchaseOrderRepository;

	    

	    // other existing methods like getAllPurchaseOrders(), createPurchaseOrder(), updateStatus()...

	    public PurchaseOrder getPurchaseOrderById(Long id) {
	        return purchaseOrderRepository.findById(id)
	                .orElseThrow(() -> new RuntimeException("Purchase Order not found with id: " + id));
	    }
	
	
	
	
	

    public PurchaseOrderService(PurchaseOrderRepository purchaseOrderRepository) {
        this.purchaseOrderRepository = purchaseOrderRepository;
    }

    public List<PurchaseOrderResponse> getAllPurchaseOrders() {
        return purchaseOrderRepository.findAll()
                .stream()
                .map(this::mapToResponse)
                .toList();
    }

    public PurchaseOrderResponse mapToResponse(PurchaseOrder order) {
        PurchaseOrderResponse dto = new PurchaseOrderResponse();
        dto.setId(order.getId());
        dto.setExpectedDeliveryDate(order.getExpectedDeliveryDate());

        // Convert enum to String
        dto.setStatus(order.getStatus().name());

        SupplierResponse supplierDto = new SupplierResponse();
        supplierDto.setId(order.getSupplier().getId());
        supplierDto.setName(order.getSupplier().getName());
        supplierDto.setEmail(order.getSupplier().getEmail());
        dto.setSupplier(supplierDto);

        List<PurchaseOrderItemResponse> items = order.getItems().stream().map(item -> {
            PurchaseOrderItemResponse i = new PurchaseOrderItemResponse();
            i.setId(item.getId());
            i.setQuantity(item.getQuantity());
            i.setProductName(item.getProduct().getProductName());
            return i;
        }).toList();
        dto.setItems(items);

        return dto;
    }
    
    public PurchaseOrder savePurchaseOrder(PurchaseOrder purchaseOrder) {
        return purchaseOrderRepository.save(purchaseOrder);
    }

    public PurchaseOrder updateStatus(Long id, PurchaseOrder.Status status) {
        PurchaseOrder order = getPurchaseOrderById(id);
        order.setStatus(status);
        return purchaseOrderRepository.save(order);
    }

    public void deletePurchaseOrder(Long id) {
        purchaseOrderRepository.deleteById(id);
    }


}
