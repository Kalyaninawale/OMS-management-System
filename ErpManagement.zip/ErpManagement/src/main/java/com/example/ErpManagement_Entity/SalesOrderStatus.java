package com.example.ErpManagement_Entity;

public enum SalesOrderStatus {
    PENDING,
    APPROVED,
    DISPATCHED
}