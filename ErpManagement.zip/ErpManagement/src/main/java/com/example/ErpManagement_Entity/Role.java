package com.example.ErpManagement_Entity;


public enum Role {
    ADMIN,
    MANAGER
}