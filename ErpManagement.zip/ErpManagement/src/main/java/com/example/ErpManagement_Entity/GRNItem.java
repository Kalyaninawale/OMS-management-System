package com.example.ErpManagement_Entity;

import jakarta.persistence.*;

@Entity
public class GRNItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "grn_id")
    private GRN grn;

    @ManyToOne
    @JoinColumn(name = "product_id")
    private Product product;

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public GRN getGrn() {
		return grn;
	}

	public void setGrn(GRN grn) {
		this.grn = grn;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public int getQuantityReceived() {
		return quantityReceived;
	}

	public void setQuantityReceived(int quantityReceived) {
		this.quantityReceived = quantityReceived;
	}

	private int quantityReceived;

    // getters & setters
}
