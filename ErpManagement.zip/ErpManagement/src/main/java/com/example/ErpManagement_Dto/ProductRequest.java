package com.example.ErpManagement_Dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductRequest {

    @NotBlank(message = "Product name is required")
    private String productName;

    // optional: if left blank, backend will auto-generate
    private String sku;

    private String category;

    @NotNull(message = "Unit price required")
    @PositiveOrZero(message = "Unit price must be >= 0")
    private Double unitPrice;

    @NotNull(message = "Current stock required")
    @Min(value = 0, message = "Current stock >= 0")
    private Integer currentStock;

    @NotNull(message = "Reorder level required")
    @Min(value = 0, message = "Reorder level >= 0")
    private Integer reorderLevel;
}
