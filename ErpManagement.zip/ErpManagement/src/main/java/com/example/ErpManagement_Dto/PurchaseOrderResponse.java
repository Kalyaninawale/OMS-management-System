package com.example.ErpManagement_Dto;

import java.time.LocalDate;
import java.util.List;

public class PurchaseOrderResponse {
    private Long id;
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public SupplierResponse getSupplier() {
		return supplier;
	}
	public void setSupplier(SupplierResponse supplier) {
		this.supplier = supplier;
	}
	public List<PurchaseOrderItemResponse> getItems() {
		return items;
	}
	public void setItems(List<PurchaseOrderItemResponse> items) {
		this.items = items;
	}
	public LocalDate getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}
	public void setExpectedDeliveryDate(LocalDate expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	private SupplierResponse supplier;
    private List<PurchaseOrderItemResponse> items;
    private LocalDate expectedDeliveryDate;
    private String status;
}

