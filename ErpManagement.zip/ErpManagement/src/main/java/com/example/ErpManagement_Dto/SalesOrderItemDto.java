package com.example.ErpManagement_Dto;

public class SalesOrderItemDto {
    private Long productId;
    private Integer quantity;
    // getters and setters
	public Long getProductId() {
		return productId;
	}
	public void setProductId(Long productId) {
		this.productId = productId;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
}