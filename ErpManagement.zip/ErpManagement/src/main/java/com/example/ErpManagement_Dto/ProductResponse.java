package com.example.ErpManagement_Dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ProductResponse {
    private Long id;
    private String productName;
    private String sku;
    private String category;
    private Double unitPrice;
    private Integer currentStock;
    private Integer reorderLevel;
}
