package com.example.ErpManagement_Dto;

import java.util.List;

public class SalesOrderDto {
    private Long customerId;
    public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public List<SalesOrderItemDto> getItems() {
		return items;
	}
	public void setItems(List<SalesOrderItemDto> items) {
		this.items = items;
	}
	private List<SalesOrderItemDto> items;
    // getters and setters
}
