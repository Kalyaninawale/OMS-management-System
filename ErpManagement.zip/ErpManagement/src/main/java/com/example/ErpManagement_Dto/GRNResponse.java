package com.example.ErpManagement_Dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class GRNResponse {
    private Long id;
    private LocalDate receivedDate;
    private Long purchaseOrderId;
    private List<GRNItemResponse> items;

    @Data
    public static class GRNItemResponse {
        private String productName;
        private Integer quantityReceived;
        private Integer currentStock; // ✅ so frontend sees updated stock
    }
}
