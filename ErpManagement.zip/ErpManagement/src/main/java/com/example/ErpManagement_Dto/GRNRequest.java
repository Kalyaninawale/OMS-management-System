package com.example.ErpManagement_Dto;

import lombok.Data;

import java.time.LocalDate;
import java.util.List;

@Data
public class GRNRequest {
    private Long purchaseOrderId;
    private LocalDate receivedDate;
    private List<GRNItemRequest> items;

    @Data
    public static class GRNItemRequest {
        private Long productId;
        private Integer quantityReceived;
    }
}
